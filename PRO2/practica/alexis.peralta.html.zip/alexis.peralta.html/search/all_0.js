var searchData=
[
  ['anadir_5fmodificar',['anadir_modificar',['../class_cjt___idiomas.html#a3ac75d8aa6e5bfcf608e102b20d71a0d',1,'Cjt_Idiomas']]]
];
