var searchData=
[
  ['tabla_5fde_5ffrecuencias',['Tabla_de_frecuencias',['../class_tabla__de__frecuencias.html',1,'Tabla_de_frecuencias'],['../class_tabla__de__frecuencias.html#ac97173bbad7bb8ce03d770cc25cf0255',1,'Tabla_de_frecuencias::Tabla_de_frecuencias()'],['../class_tabla__de__frecuencias.html#aebea3c86c0520ae8769d5f10f72345a7',1,'Tabla_de_frecuencias::Tabla_de_frecuencias(const Tabla_de_frecuencias &amp;t)']]],
  ['tabla_5fde_5ffrecuencias_2ehh',['tabla_de_frecuencias.hh',['../tabla__de__frecuencias_8hh.html',1,'']]],
  ['tamano',['tamano',['../class_cjt___idiomas.html#a52a76f01e897cacf90870507cc332731',1,'Cjt_Idiomas::tamano()'],['../class_tabla__de__frecuencias.html#a7975b81381c766725545438498ddf9f8',1,'Tabla_de_frecuencias::tamano()']]],
  ['treecode',['TreeCode',['../class_tree_code.html',1,'TreeCode'],['../class_tree_code.html#ae553c766b11ee38859aebdb012e6e457',1,'TreeCode::TreeCode()'],['../class_tree_code.html#a09a6f5b0502d5d6a8ad3d00796ca579d',1,'TreeCode::TreeCode(const TreeCode &amp;tree)']]],
  ['treecode_2ehh',['TreeCode.hh',['../_tree_code_8hh.html',1,'']]]
];
