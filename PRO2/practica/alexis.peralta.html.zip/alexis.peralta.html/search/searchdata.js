var indexSectionsWithContent =
{
  0: "acdeilmt",
  1: "cit",
  2: "cimt",
  3: "acdeilmt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones"
};

