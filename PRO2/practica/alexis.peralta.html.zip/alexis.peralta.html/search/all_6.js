var searchData=
[
  ['main',['main',['../main_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cc']]],
  ['main_2ecc',['main.cc',['../main_8cc.html',1,'']]],
  ['modificar_5ffrecuencias',['modificar_frecuencias',['../class_tabla__de__frecuencias.html#a19792d544c62db8168641b9021eb6d7a',1,'Tabla_de_frecuencias']]]
];
