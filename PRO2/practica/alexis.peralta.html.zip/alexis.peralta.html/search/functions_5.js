var searchData=
[
  ['leer_5fnombre',['leer_nombre',['../class_idioma.html#a11b13c0352c5a236204f2ced13db1fd3',1,'Idioma']]],
  ['leer_5ftabla_5ffrecuencias',['leer_tabla_frecuencias',['../class_idioma.html#a4158b3f3fc2893264d2f0ce0681816d1',1,'Idioma::leer_tabla_frecuencias()'],['../class_tabla__de__frecuencias.html#a6561a0d9c3e4dedf993b5b7baffcbfb4',1,'Tabla_de_frecuencias::leer_tabla_frecuencias()']]]
];
