var searchData=
[
  ['codificación_20y_20decodificación_20de_20textos_20con_20idiomas_2e',['Codificación y decodificación de textos con Idiomas.',['../index.html',1,'']]]
];
