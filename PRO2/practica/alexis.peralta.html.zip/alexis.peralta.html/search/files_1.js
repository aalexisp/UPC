var searchData=
[
  ['idioma_2ehh',['idioma.hh',['../idioma_8hh.html',1,'']]]
];
