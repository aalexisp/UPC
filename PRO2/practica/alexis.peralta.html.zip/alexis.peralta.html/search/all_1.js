var searchData=
[
  ['cjt_5fidiomas',['Cjt_Idiomas',['../class_cjt___idiomas.html',1,'Cjt_Idiomas'],['../class_cjt___idiomas.html#aacc903c972fabf96821406a61b20adab',1,'Cjt_Idiomas::Cjt_Idiomas()'],['../class_cjt___idiomas.html#af517b68619b6aa515100712826397607',1,'Cjt_Idiomas::Cjt_Idiomas(const Cjt_Idiomas &amp;c)']]],
  ['cjt_5fidiomas_2ehh',['cjt_idiomas.hh',['../cjt__idiomas_8hh.html',1,'']]],
  ['codifica',['codifica',['../class_cjt___idiomas.html#a7ac66c794c83fda039fcc980fd29fa01',1,'Cjt_Idiomas::codifica()'],['../class_idioma.html#a0f9878d27987efc17ecef682bcec4e9d',1,'Idioma::codifica()'],['../class_tree_code.html#a77197f6053e15a1ceb476de982341609',1,'TreeCode::codifica()']]],
  ['consultar_5fiesimo',['consultar_iesimo',['../class_tabla__de__frecuencias.html#ac769f988e9a7460b4271ffcd31613f5b',1,'Tabla_de_frecuencias']]],
  ['consultar_5fnombre',['consultar_nombre',['../class_idioma.html#a75dc0f36a42ee73a332be7f917d4677d',1,'Idioma']]]
];
