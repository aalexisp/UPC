var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html#a6722a621ce03825772493e67e5a17215',1,'Idioma::Idioma()'],['../class_idioma.html#aa7ea6b6e0cb92b73ca22413c70222461',1,'Idioma::Idioma(const Idioma &amp;l)']]]
];
