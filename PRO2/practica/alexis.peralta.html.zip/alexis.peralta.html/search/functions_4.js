var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html#aa1aa9469e2aac499c8b5508b919d0f80',1,'Idioma::Idioma(string nom, const Tabla_de_frecuencias &amp;tf)'],['../class_idioma.html#aa7ea6b6e0cb92b73ca22413c70222461',1,'Idioma::Idioma(const Idioma &amp;l)']]]
];
