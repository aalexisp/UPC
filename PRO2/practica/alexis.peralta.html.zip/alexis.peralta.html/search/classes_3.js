var searchData=
[
  ['tabla_5fde_5ffrecuencias',['Tabla_de_frecuencias',['../class_tabla__de__frecuencias.html',1,'Tabla_de_frecuencias'],['../classtabla__de__frecuencias.html',1,'tabla_de_frecuencias']]],
  ['treecode',['TreeCode',['../class_tree_code.html',1,'']]]
];
