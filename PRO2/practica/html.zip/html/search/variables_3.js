var searchData=
[
  ['t',['t',['../class_tree_code.html#a78bfa3b7f58c854a45f784f971e18282',1,'TreeCode']]],
  ['tbl',['tbl',['../class_idioma.html#a852f4eeea0bf2e349fa02e7fb494d2c1',1,'Idioma']]],
  ['tm',['tm',['../class_tree_code.html#a6494bead03eb19a418533cd29cd6d5e4',1,'TreeCode']]],
  ['tree',['tree',['../class_idioma.html#adca9670213551e71018d54e7ecab7d9b',1,'Idioma']]]
];
