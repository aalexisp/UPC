var searchData=
[
  ['anadir_5fmodificar',['anadir_modificar',['../class_cjt___idiomas.html#af26792c484d92b16af8346f781d4471b',1,'Cjt_Idiomas']]]
];
