var searchData=
[
  ['tabla_5fde_5ffrecuencias',['Tabla_de_frecuencias',['../class_tabla__de__frecuencias.html#ac97173bbad7bb8ce03d770cc25cf0255',1,'Tabla_de_frecuencias']]],
  ['tamano',['tamano',['../class_tabla__de__frecuencias.html#a7975b81381c766725545438498ddf9f8',1,'Tabla_de_frecuencias']]],
  ['treecode',['TreeCode',['../class_tree_code.html#ae553c766b11ee38859aebdb012e6e457',1,'TreeCode::TreeCode()'],['../class_tree_code.html#acc4d7e86789592a1a681a4b127ef7754',1,'TreeCode::TreeCode(Tabla_de_frecuencias &amp;tf)']]]
];
