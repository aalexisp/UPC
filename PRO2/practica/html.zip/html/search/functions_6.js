var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5ffrecuencias',['modificar_frecuencias',['../class_tabla__de__frecuencias.html#a19792d544c62db8168641b9021eb6d7a',1,'Tabla_de_frecuencias']]],
  ['modificar_5ftreecode',['modificar_treecode',['../class_idioma.html#ac9aa8f73373db5c222780e9a22737842',1,'Idioma']]]
];
