var searchData=
[
  ['anadir_5fmodificar',['anadir_modificar',['../class_cjt___idiomas.html#af26792c484d92b16af8346f781d4471b',1,'Cjt_Idiomas']]],
  ['aux',['aux',['../class_tabla__de__frecuencias.html#ac3b79c4655ed1e31aa6af0152af4bd41',1,'Tabla_de_frecuencias']]]
];
