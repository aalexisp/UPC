var searchData=
[
  ['decodifica',['decodifica',['../class_cjt___idiomas.html#ac2529cfc363db27912fce56d22d3ef93',1,'Cjt_Idiomas']]],
  ['decodifica_5fimmersion',['decodifica_immersion',['../class_tree_code.html#a27c68266d59d9512fd632c150f5447ae',1,'TreeCode']]]
];
