var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html#ae8f85553ef8e17dbcdf0122290f3c710',1,'Idioma']]],
  ['inicializa_5frecorrido',['inicializa_recorrido',['../class_tabla__de__frecuencias.html#a36ab80052e964a14f95d12cb9165e041',1,'Tabla_de_frecuencias']]],
  ['insertar',['insertar',['../class_tree_code.html#ad33c03ec90dbc046b6fcff815fb0f2a2',1,'TreeCode']]]
];
