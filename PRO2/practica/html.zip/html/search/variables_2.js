var searchData=
[
  ['nombre',['nombre',['../class_idioma.html#a0212b62724c9192a988968231c313f98',1,'Idioma']]]
];
