var searchData=
[
  ['aux',['aux',['../class_tabla__de__frecuencias.html#ac3b79c4655ed1e31aa6af0152af4bd41',1,'Tabla_de_frecuencias']]]
];
